package model;

public class FreeRoom extends Room{

    public FreeRoom(String roomNumber, RoomType roomType){
        super(roomNumber, roomType, 0.0);
    }

    @Override
    public String toString(){
        return super.toString();
    }
}

package api;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class HotelApplication {
    public static void main(String[] args) throws ParseException {

        new MainMenu();
    }
}
